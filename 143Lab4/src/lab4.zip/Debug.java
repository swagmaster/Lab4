public class Debug {
     // set dmode to false to compile out debug code
     public static final boolean dmode = true;
}	